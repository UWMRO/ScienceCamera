#!/usr/bin/env bash
../photoAcquisitionGUI.py &> ~/Desktop/crash.txt
